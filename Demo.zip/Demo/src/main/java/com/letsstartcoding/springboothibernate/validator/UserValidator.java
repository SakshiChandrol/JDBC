package com.letsstartcoding.springboothibernate.validator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.letsstartcoding.springboothibernate.dao.UserService;
import com.letsstartcoding.springboothibernate.model.User;

@Component
public class UserValidator implements Validator{

	@Autowired
	private UserService userService;
	

	public boolean supports(Class<?> aClass) {
		// TODO Auto-generated method stub
		return User.class.equals(aClass);
	}

	
	public void validate(Object o, Errors errors) {
		// TODO Auto-generated method stub
		User user=(User)o;
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "username","NotEmpty");
		if(user.getUsername().length()<6||user.getUsername().length()>32)
		{
			errors.rejectValue("username", "Size.userForm.username");
		}
		
		if(userService.findByUsername(user.getUsername())!=null)
         {
			errors.rejectValue("username", "Duplicate.userForm.username");
		}
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "password","NotEmpty");
		if(user.getPassword().length()<8||user.getPassword().length()>12)
		{
			errors.rejectValue("password", "Size.userForm.password");
		}
		if(!user.getPasswordConfirm().equals(user.getPassword()))
		{
			errors.rejectValue("passwordConfirm","Diff.userForm.passwordConfirm");
		}
		
	}

}
