package com.letsstartcoding.springboothibernate.dao;

public interface SecurityService {

	String findLoggedUserName();
	void autoLogin(String username,String password);
}
